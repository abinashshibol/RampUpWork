package pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import baseUtilities.baseUtilities;

public class CCPaymentPage extends baseUtilities {
	
public WebDriver driver;
	
	public CCPaymentPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	@FindBy(xpath="//span[contains(text(),'Credit Card')]")
	private WebElement CreditCardTitle;
	
	@FindBy (xpath="//iframe[contains(@id,'cardnumber')]")
	private WebElement CCIframe;
	@FindBy (xpath="//input[@id='ccNumber']")
	private WebElement CreditCardNumber;
	
	@FindBy (xpath="//iframe[contains(@id,'cardexpiration')]")
	private WebElement CCExpiryIframe;
	@FindBy (xpath="//input[@id='ccExpiry']")
	private WebElement CreditCardExpiry;
	
	@FindBy (xpath="//iframe[contains(@id,'cardcvv')]")
	private WebElement CCCVViframe;
	@FindBy (xpath="//input[@id='ccCVV']")
	private WebElement CreditCardCVV;
	@FindBy (xpath="//button[contains(@id,'submit-creditCard-controller')]")
	private WebElement CCSubmitButton;
	
	public void Enter_CreditCard_Details(String CCCardType){
		
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(CreditCardTitle));
	
		if(CCCardType.equalsIgnoreCase("VISA"))
		{
		iframeSwitch(CCIframe,CreditCardNumber,"4444222233331111");
		iframeSwitch(CCExpiryIframe,CreditCardExpiry,"03/22");
		iframeSwitch(CCCVViframe,CCCVViframe,"123");
	
		}
		else if(CCCardType.equalsIgnoreCase("MASTERCARD"))
		{
		iframeSwitch(CCIframe,CreditCardNumber,"5111111111111118");
		iframeSwitch(CCExpiryIframe,CreditCardExpiry,"03/22");
		iframeSwitch(CCCVViframe,CCCVViframe,"123");
		}
		else if(CCCardType.equalsIgnoreCase("AMEX"))
		{
		iframeSwitch(CCIframe,CreditCardNumber,"5111111111111118");
		iframeSwitch(CCExpiryIframe,CreditCardExpiry,"03/22");
		iframeSwitch(CCCVViframe,CCCVViframe,"123");
		}
		else 
		{
			System.out.println("Please enter a Card type on the Property File");
		
		}
	CCSubmitButton.click();
}
	
}
