package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPage {
	
public WebDriver driver;
	
	public CartPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	
	
	@FindBy (xpath="//button[normalize-space()='View Cart']")
	private WebElement ViewCart;
	
	@FindBy (xpath="//button[normalize-space()='Checkout']")
	private WebElement Checkout;
	
	public void Cart_Checkout(){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		ViewCart.click();
		js.executeScript("arguments[0].click()", Checkout);
		//Checkout.click();
		 }
  
	
	
}
