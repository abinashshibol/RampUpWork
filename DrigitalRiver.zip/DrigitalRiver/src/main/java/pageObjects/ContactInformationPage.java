package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
public class ContactInformationPage {
	
public WebDriver driver;
	
	public ContactInformationPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	@FindBy (xpath="//h3[contains(text(),'Contact Information')]")
	private WebElement ContactTiltle;
	@FindBy (xpath="//input[@id='firstNameField']")
	private WebElement CustomerFirstName;
	@FindBy (xpath="//input[@id='lastNameField']")
	private WebElement CustomerLastName;
	@FindBy (xpath="//input[@id='homePhoneField']")
	private WebElement CustomerHomePhone;
	@FindBy (xpath="//input[@id='emailField']")
	private WebElement CustomerEmailField;
	
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='firstName']")
	private WebElement BillingFirstName;
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='lastName']")
	private WebElement BillingLastName;
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='companyName']")
	private WebElement BillingCompany;
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='address1']")
	private WebElement BillingAddress1;
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='address2']")
	private WebElement BillingAddress2;
	@FindBy (xpath="//select[@name='billingAddress.countryCode']")
	private WebElement BillingCountry;
	@FindBy (xpath="//select[@name='billingAddress.stateCode']")
	private WebElement BillingState;
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='city']")
	private WebElement BillingCity;
	@FindBy (xpath="//form[@id='billingAddressForm']//input[@id='postalCode']")
	private WebElement BillingPostalCode;
	@FindBy (xpath="//a[normalize-space()='Use Billing Address']")
	private WebElement UseBillingAddress;
	@FindBy (xpath="//input[@value='Continue']")
	private WebElement BillingContinue;
	
	public void Enter_Customer_Information(String FirstName, String LastName, String HomePhone, String Email){
		Assert.assertEquals(true, ContactTiltle.isDisplayed());
		
		CustomerFirstName.clear();
		CustomerFirstName.sendKeys(FirstName);
		CustomerLastName.clear();
		CustomerLastName.sendKeys(LastName);
		CustomerHomePhone.clear();
		CustomerHomePhone.sendKeys(HomePhone);
		CustomerEmailField.clear();
		CustomerEmailField.sendKeys(Email);
	 }
	
	public void Enter_Billing_Information(String BillFirstName, String BillLastName, String BillCompanyName, String BillAddress1, String BillAddress2, String BillCountry, String BillState, String BillCity, String BillPostalCode ) throws InterruptedException{
		BillingFirstName.clear();
		BillingFirstName.sendKeys(BillFirstName);
		BillingLastName.clear();
		BillingLastName.sendKeys(BillLastName);
		BillingCompany.clear();
		BillingCompany.sendKeys(BillCompanyName);
		BillingAddress1.clear();
		
		BillingAddress1.sendKeys(BillAddress1);
		Thread.sleep(3000);
		BillingAddress2.clear();
		BillingAddress2.sendKeys(BillAddress2);
		Thread.sleep(3000);
		System.out.println(BillCountry);
		System.out.println(BillState);
		
		
		Select option1 = new Select(BillingCountry);
		option1.selectByVisibleText(BillCountry);
		Select option2 = new Select(BillingState);
		option2.selectByVisibleText(BillState);
		BillingCity.clear();
		BillingCity.sendKeys(BillCity);
		BillingPostalCode.clear();
		BillingPostalCode.sendKeys(BillPostalCode);
		UseBillingAddress.click();
		BillingContinue.click();
		
		
	 }
}
