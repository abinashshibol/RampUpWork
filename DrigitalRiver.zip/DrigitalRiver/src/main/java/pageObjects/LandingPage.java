package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LandingPage {
	
	public WebDriver driver;
	
	public LandingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	@FindBy (xpath="//a[@class='goToLogin cc_goto_login']")
	private WebElement Loginlogo;
	
	public void NavigateToLoginPage(){
		Loginlogo.click();
		 }
	
}
