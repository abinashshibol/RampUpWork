package pageObjects;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	
public WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	@FindBy (xpath="//input[@id='emailField']")
	private WebElement UserName;
	
	@FindBy (xpath="//input[@id='passwordField']")
	private WebElement Password;
	
	@FindBy (xpath="//input[@id='send2Dsk']")
	private WebElement LoginButton;
	
	
	public void LogIn_Action(String uName, String pwd){
		UserName.sendKeys(uName);
		Password.sendKeys(pwd);
		LoginButton.click();
		 }
	

}
