package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class OrderConfirmationPage {
	
	public WebDriver driver;
	
	public OrderConfirmationPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	private By OrderConfirmation= By.className("cc_order_confirmation_date");
	

	public WebElement getOrderConfirmation()
	{
	
		return driver.findElement(OrderConfirmation);
	}

}
