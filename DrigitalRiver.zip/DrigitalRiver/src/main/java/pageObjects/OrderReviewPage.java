package pageObjects;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class OrderReviewPage {
	
public WebDriver driver;
	
	public OrderReviewPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	 @FindBy (css="#nonSubscriptionTerms")
		private WebElement NonSubscriptionTerm;
		@FindBy (xpath="//input[@id='acceptTermsButton']")
		private WebElement AcceptTermButton;
	 
		@FindBy (xpath="//h3[contains(text(),'General Information')]")
		private WebElement OrderReviewTitle;
		
		
		public void Verify_Order_Review(){
			
			Assert.assertEquals(true, OrderReviewTitle.isDisplayed());
			String title = OrderReviewTitle.getText();
			System.out.println(title);
			Assert.assertEquals(true, NonSubscriptionTerm.isDisplayed());
			Assert.assertEquals(true, AcceptTermButton.isDisplayed());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click()", NonSubscriptionTerm);
			//NonSubscriptionTerm.click();
			js.executeScript("arguments[0].click()", AcceptTermButton);
			//AcceptTermButton.click();
		 }
	
}
