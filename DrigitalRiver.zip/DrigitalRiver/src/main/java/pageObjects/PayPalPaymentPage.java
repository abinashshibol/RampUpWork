package pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PayPalPaymentPage {
	
public WebDriver driver;
	
	public PayPalPaymentPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	@FindBy (xpath="//iframe[contains(@id,'cardnumber')]")
	private WebElement CCIframe;
	@FindBy (xpath="//input[@id='ccNumber']")
	private WebElement CreditCardNumber;
	
	@FindBy (xpath="//iframe[contains(@id,'cardexpiration')]")
	private WebElement CCExpiryIframe;
	@FindBy (xpath="//input[@id='ccExpiry']")
	private WebElement CreditCardExpiry;
	
	@FindBy (xpath="//iframe[contains(@id,'cardcvv')]")
	private WebElement CCCVViframe;
	@FindBy (xpath="//input[@id='ccCVV']")
	private WebElement CreditCardCVV;
	@FindBy (xpath="//button[contains(@id,'submit-creditCard-controller')]")
	private WebElement CCSubmitButton;
	
	
	
	
	
}
