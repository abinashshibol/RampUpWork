package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class ProductPage {
	
public WebDriver driver;
	
	public ProductPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	@FindBy (xpath="//a[normalize-space()='Products']")
	private WebElement ProductMenu;
	
	@FindBy (xpath="//a[normalize-space()='ALL PRODUCTS']")
	private WebElement AllProductDropdown;
	
	@FindBy (xpath="//a[@class='cc_product_name gp_prod'][normalize-space()='Capricorn II Group Espresso Machine']")
	private WebElement CapricornIIGroupEspressoMachine;
	
	@FindBy (xpath="//input[@id='qty']")
	private WebElement ProductQuanity;
	
	@FindBy (xpath="//button[normalize-space()='Add to Cart']")
	private WebElement Addtocartbutton;
	
	public void GetProduct_Menu(String Quanity) throws InterruptedException{
		ProductMenu.click();
		AllProductDropdown.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		System.out.println("I am on the screen");
		js.executeScript("arguments[0].scrollIntoView();",CapricornIIGroupEspressoMachine );
		CapricornIIGroupEspressoMachine.click();
		ProductQuanity.clear();
		ProductQuanity.sendKeys(Quanity);
		boolean addtoCartButton = Addtocartbutton.isDisplayed();
		System.out.println(addtoCartButton);
         js.executeScript("arguments[0].click()", Addtocartbutton);
		//Assert.assertTrue(ExpectedConditions.elementToBeClickable(Addtocartbutton).apply(driver).click());
		//Addtocartbutton.click();
		
		 }

}
