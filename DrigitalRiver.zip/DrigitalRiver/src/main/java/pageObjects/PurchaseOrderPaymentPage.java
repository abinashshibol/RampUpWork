package pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PurchaseOrderPaymentPage {
	
public WebDriver driver;
	
	public PurchaseOrderPaymentPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	private By PO = By.xpath("//a[normalize-space()='Purchase Order']");
	private By POAccountNumber = By.xpath("//input[@name='accountNumber']");
	private By POName = By.xpath("//input[@name='displayName']");
	private By POProcessPayment = By.xpath("//input[@value='Process Payment']");
	
	
	public WebElement getPO()
	{
		return driver.findElement(PO);
	}
	public WebElement getPOAccountNumber()
	{
		return driver.findElement(POAccountNumber);
	}
	public WebElement getPOName()
	{
	
		return driver.findElement(POName);
	}
	public WebElement getPOProcessPayment()
	{
	
		return driver.findElement(POProcessPayment);
	}
	
}
