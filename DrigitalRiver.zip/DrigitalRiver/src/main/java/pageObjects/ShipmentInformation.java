package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ShipmentInformation {
	
public WebDriver driver;
	
	public ShipmentInformation(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	
	@FindBy (xpath="//select[@id='shippingMethod']")
	private WebElement ShippingMethod;
	@FindBy (xpath="//input[@id='estShipping']")
	private WebElement EstimatedShipping;
	@FindBy (css="#shippingNotes")
	private WebElement ShippingNotes;
	@FindBy (xpath="//input[@value='Accept Terms and Proceed']")
	private WebElement AcceptTermsAndProceed;

	public void Enter_Shipment_Information(){
		
		ShippingMethod.click();
		Select dropdown = new Select(ShippingMethod);
        dropdown.selectByValue("DefaultStore - Next Day");
        EstimatedShipping.click();
		ShippingNotes.clear();
		ShippingNotes.sendKeys("Testing Shipping Notes with Automation Script");
		AcceptTermsAndProceed.click();
	 }
	
	
}
