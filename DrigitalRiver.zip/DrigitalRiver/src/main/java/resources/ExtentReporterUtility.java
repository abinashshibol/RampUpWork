package resources;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import baseUtilities.baseUtilities;

public class ExtentReporterUtility extends baseUtilities {
	
	static ExtentReports extent ;
	
	public static ExtentReports getReportObject(String Tester)
	{
		
	String reportPath =	System.getProperty("user.dir")+"\\reports\\index.html";
		ExtentSparkReporter repoter = new ExtentSparkReporter(reportPath);
		
		repoter.config().setReportName("DRAutomation");
		repoter.config().setDocumentTitle("DigitalRiver Test");
       // 
		
		 extent = new ExtentReports();
		extent.attachReporter(repoter);
		extent.setSystemInfo("Tester Name", "Abinash");
		
		return extent;
		
	}
	

}
