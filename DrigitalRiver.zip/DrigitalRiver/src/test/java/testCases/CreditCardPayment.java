package testCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import baseUtilities.baseUtilities;
import pageObjects.CartPage;
import pageObjects.LandingPage;
import pageObjects.LoginPage;
import pageObjects.OrderReviewPage;
import pageObjects.CCPaymentPage;

public class CreditCardPayment extends baseUtilities {

	public static Logger log = LogManager.getLogger(baseUtilities.class.getName());
	public WebDriver driver; // keeping driver as local for the parallel
								// execution
	// other wise it will override the basUtility driver

	@BeforeTest
	public void initialize() throws IOException, InterruptedException {
		// initialize the browser
		driver = initializeDriver();
		log.info("Driver Initialized");
		// initialize URL
		driver = gettingURL(driver);
		log.info("Navigated to the URL");

	}

	@Test(groups = { "Regression" })

	public void CreditCardPaymentFlow() throws IOException, InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String UserName = prop.getProperty("username");
		String Password = prop.getProperty("password");
		String Quanity = prop.getProperty("Quanity");
		String BillingCountry = prop.getProperty("BillingCountry");
		String BillingState = prop.getProperty("BillingState");
		String Domain = prop.getProperty("Domain");
		String CCCardType=prop.getProperty("CCCardType");
		String Text = "General User";
		
		GenericPageFlow genericPage = PageFactory.initElements(driver, GenericPageFlow.class);
		CCPaymentPage ccPaymentPg = PageFactory.initElements(driver, CCPaymentPage.class);
		// Kick off the Generic Flow 
		genericPage.basePageNavigation(UserName, Password, Quanity, BillingCountry, BillingState, Domain, driver);
	    // Credit Card info
		ccPaymentPg.Enter_CreditCard_Details(CCCardType);
		
	}

	@AfterTest
	public void closeBrowser() {

		driver.close();
	}

}
