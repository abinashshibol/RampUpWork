package testCases;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import com.github.javafaker.Faker;
import com.github.javafaker.Number;
import org.openqa.selenium.JavascriptExecutor;
import baseUtilities.baseUtilities;
import pageObjects.CartPage;
import pageObjects.LandingPage;
import pageObjects.LoginPage;
import pageObjects.OrderReviewPage;
import pageObjects.ProductPage;
import pageObjects.ShipmentInformation;
import pageObjects.ContactInformationPage;

public class GenericPageFlow extends baseUtilities {
	public static Logger log = LogManager.getLogger(baseUtilities.class.getName());
	public WebDriver driver;
	// this is a Base page Flow generic to All the cases 
	// keeping driver as local for the parallel execution
	// other wise it will override the basUtility driver
	@BeforeTest
	public void initialize() throws IOException {
		// initialize the browser
		driver = initializeDriver();
		log.info("Driver Initialized");
		// initialize URL
		driver = gettingURL(driver);
		log.info("Navigated to the URL");
	}
 // dataProvider = "getData",
	@Test( groups = { "Generic" })

	public void basePageNavigation(String UserName, String Password, String Quanity,String BillingCountry, String BillingState,String Domain, WebDriver driver) throws IOException, InterruptedException {
		
		Faker fake = new Faker();
		LoginPage loginPg = PageFactory.initElements(driver, LoginPage.class);
		LandingPage landingPg = PageFactory.initElements(driver, LandingPage.class);
		ProductPage productPg = PageFactory.initElements(driver, ProductPage.class);
		CartPage cartPg = PageFactory.initElements(driver, CartPage.class);
		ContactInformationPage contactInfoPg = PageFactory.initElements(driver, ContactInformationPage.class);
		ShipmentInformation shipmentPg = PageFactory.initElements(driver, ShipmentInformation.class);
		OrderReviewPage orderReviewPg = PageFactory.initElements(driver, OrderReviewPage.class);
		
		// Open the MainPage and Click the Login Button 
		landingPg.NavigateToLoginPage();
		// From Login page enter Valid UserName And password then Submit 
		loginPg.LogIn_Action(UserName, Password);
		// Product Page 
		productPg.GetProduct_Menu(Quanity);
		// CartPage and Checkout
		cartPg.Cart_Checkout();
		//ContactInformationPage
		String FirstName = fake.name().firstName();
		String LastName = fake.name().lastName();
		String HomePhone = fake.phoneNumber().phoneNumber();
		String BillingFirstName = fake.name().firstName();
		String BillingLastName = fake.name().lastName();
		String BillingAddress1 = fake.address().streetAddress();
		String BillingAddress2 = fake.address().streetAddressNumber();
		String BillingCompany = fake.company().industry();
		String BillingCity = fake.address().cityName();
		String BillingPostalCode = fake.address().zipCode();
		String Email = emailAddress(randomString(), Domain);
		contactInfoPg.Enter_Customer_Information(FirstName, LastName, HomePhone, Email);
		contactInfoPg.Enter_Billing_Information(BillingFirstName, BillingLastName, BillingCompany, BillingAddress1, BillingAddress2, BillingCountry, BillingState, BillingCity, BillingPostalCode);
		// Shipping Information 
		shipmentPg.Enter_Shipment_Information();
		//OrderReviewPage
		orderReviewPg.Verify_Order_Review();

	}

//	@DataProvider
// 	public Object[][] getData() {
//		// row stands for how many different data
//		// colomn stands for the number of values for each test
//		Object[][] data = new Object[1][3];
//
//		// 1st user name and password
//		data[0][0] = "paul.brown@yopmail.com";
//		data[0][1] = "OctNov@2020";
//		data[0][2] = driver;
//		// 2nd user name and password
//		/*
//		 * data[1][0] = "paul.brown@yopmail.com"; data[1][1] ="OctNov@2020";
//		 * data[1][2] = "No PL User";
//		 */
//
//		return data;
//
//	} 



@AfterTest
	public void closeBrowser() {

		driver.close();
	}

}
